A=input('Ingrese la matriz A = ');
b=input('\nIngrese el vector b ');

[n,m]=size(A);
C=[A,b];
fprintf('\nLa matriz aumentada es = \n');
if n==m 
    for k=1:(n-1)
        fprintf('\n ETAPA %g=\n\n',k)
        mayor=0; 
        filam=k; 
        for p=k:n
            if mayor<abs(C(p,k)) 
                mayor=abs(C(p,k));
                filam=p; 
            end
        end
        if mayor ==0
            fprintf('El metodo tiene infinitas soluciones')
            break 
        else
            if filam ~= k
                for j=1:(n+1)
                    aux=C(k,j);
                    C(k,j)=C(filam,j);
                    C(filam,j)=aux 
                end
            end
        end
        fprintf('\nMatriz correspondiente:\n')
        disp(C)
        fprintf('\nMultiplicadores :\n')
        for i=(k+1):n
            m(i,k)=C(i,k)/C(k,k);
            fprintf('\nm(%g,%g)=',i,k)
            disp(m(i,k));
            for j=k:(n+1)
                C(i,j)= C(i,j) - m(i,k)*C(k,j);
            end
        end
        fprintf('\nMatriz correspondiente:\n')
        disp(C)
    end
    for i=n:-1:1
        suma=0;
        for p=(i+1):n
            suma = suma + C(i,p)*X(p);
        end
        X(i)=(C(i,n+1)-suma)/C(i,i);
    end
else
    fprintf('\nERROR: La matriz NO es cuadrada\n');
end
fprintf('\n\nMatriz final:\n');
disp(C)
fprintf('\n\nSolucion X1-Xn:\n');
for i=1:n
    Xi=X(1,i);
    fprintf('\nX%g=',i)
    disp(Xi);
end