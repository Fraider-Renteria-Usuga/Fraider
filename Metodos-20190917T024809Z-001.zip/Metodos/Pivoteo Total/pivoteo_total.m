A = input('Ingrese la matriz A:  ');
b = input('Ingrese la matriz b:  ');
[f,c] = size(A);
Ab=[A b]
for i = 1 : n
    marca(i) = i;
end
if det(A)==0
	disp('el sistema no tiene solucion')
else
    for d = 1 : n - 1
		mayor = abs(Ab(d,d));
		filam = d;
		columnam = d;
		for f = d : n
			for j = d : n
				if abs(Ab(f,j)) > mayor
					mayor = abs(Ab(f,j));
					filam = f;
					columnam = j;
				end
			end
        end
        fprintf('\n el numero mayor es  %g  y se encuentra en la fila  %g  y la columna  %g \n',mayor,filam,columnam)
        if filam ~= d
            auxi = Ab(filam,:);
			Ab(filam,:) = Ab(d,:);
			Ab(d,:)= auxi;
        end
        if columnam ~= d
			auxi = Ab(:,columnam);
			Ab(:,columnam) = Ab(:,d);
			Ab(:,d)= auxi;
			auxi = marca(columnam);
			marca(columnam)= marca(d);
			marca(d)= auxi;
        end
        
        for s = d + 1 : n
			multi = Ab(s,d) / Ab(d,d);
			fprintf('\n El multiplicador para esta etapa es: %g \n',multi);
            for i = 1 : n + 1
				Ab(s,i) = Ab(s,i) - multi * Ab(p);
			end
			Ab
		end
    end
    for i = n : -1 : 1
		cont = 0;
        for s = (i+1):n
            cont =cont+Ab(i,s)*X(s,1); 
        end
        X(i) = (Ab(i,n+1) - cont) / Ab(i,i);
    end
	
	fprintf('\n La solucion del sistema es: \n');
	for j=1:n
		fprintf('\n  X%g = %g\n',marca(j),x(j));
	end
		fprintf('\n La solucion real obtenida por OCTAVE es: \n');
	xr=inv(A)*b;
	for j=1:n
		fprintf('\n  X%g = %g\n',j,xr(j));
	end
end