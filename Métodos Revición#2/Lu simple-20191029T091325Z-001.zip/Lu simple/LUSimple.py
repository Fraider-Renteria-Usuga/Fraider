from funciones import *
import numpy as np
def LUSimple(matriz,vectorSol):
    n=len(matriz)
    L=np.zeros((n,n))
    U=np.zeros((n,n))
    for i in range(n):
        L[i][i]=1
        U[0][i]=matriz[0][i]
        for j in range(i+1,n):
            mult=(matriz[j][i]) / (matriz[i][i])
            L[j][i]=mult
            for k in range(n):
                matriz[j][k]=matriz[j][k]-(mult*matriz[i][k])
                U[j][k]=matriz[j][k]
    vecz=sustProgre(L,vectorSol)
    sln=sustRegre(U,vecz) #Vector donde estan las x
    return(L,U,sln)
#Comando para imprimir de una manera clara al usuario
#print("Matriz L\n"+str(L))
#print("Matriz U\n"+str(U))
#print("La solución al sistema es: ")
#for i in range(n):
    #print("x"+str(n+1)+": "+str(sln[i]))"""