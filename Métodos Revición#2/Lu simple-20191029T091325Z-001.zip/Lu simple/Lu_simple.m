clear
clc
a=input("ingrese la matriz de coeficientes: ");
b=input("ingrese el vector b: ");
v=[a,b];
[n,m]=size(v);
u=zeros(n);
o=zeros(n);
x=zeros(n,1);
for f=1:n
    for c=(f+1):n
        o(c,f)=v(c,f)/v(f,f);
        for k=1:(n+1)
            v(c,k)=v(c,k)-(o(c,f)*v(f,k));
        end
    end
end
for j=1:n
    o(j,j)=o(j,j)+1;
end
for i=1:n
    for g=1:n
        u(i,g)=v(i,g);
    end
end
cont=0;

disp(x)
fprintf("la matriz aumentada pivotada es: \n")
disp(v)

fprintf("la matriz L es: \n")
disp(o)

fprintf("la matriz U es: \n")
disp(u)
for i=n:-1:1
    suma=0;
    for p=(i+1):n
        suma = suma + v(i,p)*X(p);
    end
    X(i)=(v(i,n+1)-suma)/v(i,i);
end
fprintf("\nlas soluciones de X1 - X%g son: \n",n)
for i=1:n
    Xi=X(1,i);
    fprintf('\nX%g=',i)
    disp(Xi)
end