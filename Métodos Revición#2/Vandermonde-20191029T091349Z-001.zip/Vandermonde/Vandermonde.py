import numpy as np
from funciones import *
from GaussPivTotal import PivTotal
def vandermonde(xi,yi):
    n=len(xi)
    matriz=np.zeros((n, n))
    vector=np.zeros(n)
    for i in range(n):
        cont=n-1
        for j in range(n):
            matriz[i][j]=xi[i]**(cont)
            cont-=1
            vector[i]=yi[i]
    matriz1,vectorSol=PivTotal(matriz, vector)
    sln=sustRegre(matriz1, vectorSol)
    return(matriz,sln)
#Comando para imprimir de una manera clara al usuario
#sub=n-1
#for i in sln:
    #print("a"+str(sub)+": "+str(i))
    #sub-=1
