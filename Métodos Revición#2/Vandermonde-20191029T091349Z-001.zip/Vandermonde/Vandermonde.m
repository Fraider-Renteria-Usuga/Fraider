function [vectorXsol] = Vandermonde(x,y) %Ingrese los vectores X y Y, separando los valores por;
    
    [f,c]=size(x);%Leo el tamaño de la matriz para hazi saber el tamaño de los ciclos que debo formar
    
    for i=1 : f %Para recorrer y llenar las filas de la matriz A
        for j=1 :f%Para recorrer las columnas y llenar las filas de la matriz A
           A(i,j)=x(i)^(f-j) %La base corresponde al vector X, y con (f-j) obtengo la potencia, esta disminuye en cada paso y regresa a su valor inicial cual baja a la siguiente fila
        end
    end
    vectorXsol=Cholesky(A,y)% Teniendo la matriz A y el Vector B, solo resta resolver la matriz

end