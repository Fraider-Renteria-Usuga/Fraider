import numpy as np
from funciones import *
def Doolittle(A,b):
    n=len(A)
    L=np.identity(n)
    U=np.zeros((n,n))
    for k in range(n):
        for i in range(n):
            SumaL=0
            Sumakk=0
            for p in range(k):
                SumaL+=L[i][p]*U[p][k]
                Sumakk+=L[k][p]*U[p][k]
            U[k][k]=A[k][k]-Sumakk
            L[i][k]=(A[i][k]-SumaL)/U[k][k]
        for j in range(k+1,n):
            SumaU=0
            for p in range(k):
                SumaU+=L[k][p]*U[p][j]
            U[k][j]=(A[k][j]-SumaU)/L[k][k]
    z=sustProgre(L,b)
    sln=sustRegre(U,z)
    return(L,U,sln)
#Comando para imprimir de una manera clara al usuario
#print("Matriz L\n"+str(L))
#print("Matriz U\n"+str(U))
#print("La solución al sistema es: ")
#for i in range(n):
    #print("x"+str(n+1)+": "+str(sln[i]))"""