def PivParcial(matriz,vectorSol):
  n=len(matriz)
  for i in range(n):
    if matriz[i][i]==0:#Si hay un cero en la diagonal
      for p in range(i+1,n):
        if matriz[p][i]!=0:
          matriz[[p,i]]=matriz[[i,p]]
          vectorSol[p],vectorSol[i]=vectorSol[i],vectorSol[p]
          break
    lis=[]
    for h in range(i,n):
      lis.append(abs(matriz[h][i]))
    for maxicol in range(i,n):
      if abs(matriz[maxicol][i])==(max(lis)):
        matriz[[i,maxicol]]=matriz[[maxicol,i]]
        vectorSol[maxicol],vectorSol[i]=vectorSol[i],vectorSol[maxicol]
    for j in range(i+1,n):
      mult=(matriz[j][i])/(matriz[i][i])
      vectorSol[j]=vectorSol[j]-(mult*vectorSol[i])
      for k in range(0,n):
        matriz[j][k]=matriz[j][k]-(mult*matriz[i][k])
  return(matriz,vectorSol)