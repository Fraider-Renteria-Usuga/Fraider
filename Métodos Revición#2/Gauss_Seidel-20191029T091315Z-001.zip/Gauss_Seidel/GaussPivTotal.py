def PivTotal(matriz,vectorSol):
  n=len(matriz)
  for i in range(n):
    if matriz[i][i]==0:#Si hay un cero en la diagonal
      for p in range(i+1,n):
        if matriz[p][i]!=0:
          matriz[[p,i]]=matriz[[i,p]]
          vectorSol[p],vectorSol[i]=vectorSol[i],vectorSol[p]
          break
    lis=[]
    for h in range(i,n):
      for t in range(i,n):
        lis.append(matriz[h][t])
    for j in range(i,n):
      for s in range(i,n):
        if matriz[j][s]==(max(lis)):
          matriz[[i,j]]=matriz[[j,i]]
          vectorSol[j],vectorSol[i]=vectorSol[i],vectorSol[j]
          for r in range(i,n):
            matriz[r][i],matriz[r][s]=matriz[r][s],matriz[r][i]
    for j in range(i+1,n):
      mult=(matriz[j][i])/(matriz[i][i])
      vectorSol[j]=vectorSol[j]-(mult*vectorSol[i])
      for k in range(0,n):
        matriz[j][k]=matriz[j][k]-(mult*matriz[i][k])
  return(matriz,vectorSol)