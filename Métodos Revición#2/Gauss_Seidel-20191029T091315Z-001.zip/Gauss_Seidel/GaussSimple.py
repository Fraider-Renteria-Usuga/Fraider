def GauSimple(matriz,vectorSol):
  n=len(matriz)
  for i in range(n):
    if matriz[i][i]==0:
      for p in range(i+1,n):
        if matriz[p][i]!=0:
          matriz[[p,i]]=matriz[[i,p]]
          vectorSol[p],vectorSol[i]=vectorSol[i],vectorSol[p]
          break
    for j in range(i+1,n):
      mult=(matriz[j][i])/(matriz[i][i])
      vectorSol[j]=vectorSol[j]-(mult*vectorSol[i])
      for k in range(0,n):
        matriz[j][k]=matriz[j][k]-(mult*matriz[i][k])
  return(matriz,vectorSol)