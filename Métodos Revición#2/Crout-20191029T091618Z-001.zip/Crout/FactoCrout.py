import numpy as np
from funciones import *
def Crout(A,b):
  n=len(A)
  L=np.zeros((n,n))
  U=np.identity(n)
  for k in range(n):
    for i in range(n):
      SumaL=0
      SumaU=0
      for p in range(k):
        SumaL+=L[i][p]*U[p][k]
        SumaU+=L[k][p]*U[p][i]
      L[i][k]=A[i][k]-SumaL
      if L[k][k]!=0:
          U[k][i]=(A[k][i]-SumaU)/L[k][k]
  z=sustProgre(L,b)
  sln=sustRegre(U,z)
  return(L,U,sln)
#Comando para imprimir de una manera clara al usuario
#print("Matriz L\n"+str(L))
#print("Matriz U\n"+str(U))
#print("La solución al sistema es: ")
#for i in range(n):
    #print("x"+str(n+1)+": "+str(sln[i]))"""