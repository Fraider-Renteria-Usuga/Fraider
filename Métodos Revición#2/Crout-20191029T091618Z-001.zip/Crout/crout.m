format long
a=input("ingrese la matriz a: ");
[n,m]=size(a);
l=zeros(n);
u=zeros(n);
for i=1:n 
    l(i,1)=a(i,1);
    u(1,i)=a(1,i)/a(1);
    u(i,i)=1;
end
for i=2:n
    cont=0;
    for j=i:n
        l(j,i)=a(j,i)-l(j,:)*u(:,i);
    end
    for k=i:n-1 
        u(i,k+1)=(a(i,k+1)-l(k,:)*u(:,k+1))/(l(i,i));
    end
end
fprintf("Matriz L\n")
disp(l)
fprintf("Matriz U\n")
disp(u)