import numpy as np
def jacobi(A,b,xk,tol,iter):
    n=len(A)
    Error=0
    cont=0
    for k in range(iter):
        mayorError = 0
        print("Iteración " + str(k + 1))
        xactual = np.zeros(n)
        for i in range(n):
            Sumxi = 0
            for j in range(n):
                if i != j:
                    Sumxi += A[i][j] * xk[j]
            xactual[i] = ((-1 / A[i][i]) * Sumxi) + (b[i] / A[i][i])
            print("x" + str(i + 1) + ": " + str(xactual[i]))
            mayorError+=((xactual[i]-xk[i])**2)
        xk=xactual
        Error=(mayorError)**(0.5)
        print("Error: " +str(Error))
        cont+=1
        if Error < tol:
            break
    if iter==cont:
        print("Supero el Nmax de iteraciones\nIntroduzca un mejor vector inicial ")
    return(xactual,Error,cont)