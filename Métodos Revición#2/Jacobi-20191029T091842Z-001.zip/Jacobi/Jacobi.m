function [X] = Jacobi(A,b,x0,tol,iter)
    [f,c]=size(A);%Calculo el tamaño de la Matriz A
    cont=0;
    err=1
    while err > tol & cont < iter %inico ciclo que tiene como restricciones las iteracciones y el mayor de los errores de los componentes del vectorXn y el vector Xn-1   
        for i=1 : f
            suma=0;
            xn=x0;
            xn(i)=0;
            for j=1 : f            
                suma=suma+xn(j)*A(i,j); %Calculo la suma que posteriormente pasara al otro lado a restar
            end
     
            X(i)=(b(i)-suma)/A(i,i);%Queda el valor Xi despejado en terminos del vector b, la suma y el punto que al que pertenecia Xi en la matriz, este pasa a dividir
        end
        del=abs(X-x0);%Calculo todos los errores y los almaceno en del
        err=max(del);%El error que tomo para la comparación es el mayor de todos para eso uso la función mas
        x0=X;%X0 toma el valor de X para empezar de nuevo el proceso
        cont=cont+1;% El contador que se encarga de que el programa no supere las iteraciones
    end
end