import numpy as np
def sor(A,b,xk,tol,w,iter):
    n=len(A)
    Error = 0
    cont = 0
    for k in range(iter):
        mayorError = 0
        print("\nIteración " + str(k + 1) + "\n")
        xactual = np.zeros(n)
        for i in range(n):
            Sumxi = 0
            for j in range(i):
                Sumxi += A[i][j] * xactual[j]
            for j in range(i + 1, n):
                Sumxi += A[i][j] * xk[j]
            xactual[i] = ((1 - w) * xk[i]) - ((w / A[i][i]) * Sumxi) + ((w * b[i]) / A[i][i])
            print("x" + str(i + 1) + ": " + str(xactual[i]))
            mayorError += ((xactual[i] - xk[i]) ** 2)
        xk = xactual
        Error = (mayorError) ** (0.5)
        print("Error: " + str(Error))
        cont += 1
        if Error < tol:
            break
    if iter == cont:
        print("Supero el Nmax de iteraciones sin llegar a su tolerancia \nMejore el valor de relajación  ")
    return (xactual, Error, cont)