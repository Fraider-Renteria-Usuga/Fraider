import numpy as np
from funciones import *
def LUParcial(matriz,b):
    n=len(matriz)
    P = np.identity(n)
    L = np.zeros((n, n))
    for i in range(n):
        if matriz[i][i] == 0:  # Si hay un cero en la diagonal
            print("Error\nSe encontró un cero en la diagonal ")
            break
        lis = []
        for h in range(i, n):
            lis.append(abs(matriz[h][i]))
        for maxicol in range(i, n):
            if abs(matriz[maxicol][i]) == (max(lis)):
                matriz[[i, maxicol]] = matriz[[maxicol, i]]
                P[[i, maxicol]] = P[[maxicol, i]]
                L[[i, maxicol]] = L[[maxicol, i]]
        L[i][i] = 1
        for j in range(i + 1, n):
            mult = (matriz[j][i]) / (matriz[i][i])
            L[j][i] = mult
            for k in range(n):
                matriz[j][k] = matriz[j][k] - (mult * matriz[i][k])
    U=matriz
    Bn=P@b #Multiplique la matriz con el vector
    vecz=sustProgre(L,Bn)
    sln=sustRegre(U,vecz)
    return(L,U,sln)
#Comando para imprimir de una manera clara al usuario
#print("Matriz L\n"+str(L))
#print("Matriz U\n"+str(U))
#print("La solución al sistema es: ")
#for i in range(n):
    #print("x"+str(n+1)+": "+str(sln[i]))"""