function [vectorY] = sustRegresiva(matrizRt,vectorB,f)
 

vectorY(1)=vectorB(1)/matrizRt(1);

for i=2:1:f
    suma=0;
    for j=1 : i-1 
        suma=suma+(matrizRt(i,j)*vectorY(j));
    end
    vectorY(i)=(vectorB(i)-suma)/matrizRt(i,i);
    
end
end