function [vectorX] = sustRegresiva(matrizR,vectorY,f)
    
vectorX(f)=vectorY(f)/matrizR(f,f);
for i=f-1:-1:1
    suma1=0;
    for j=f:-1:i+1
        suma1=suma1+(matrizR(i,j)*vectorX(j));
    end
    vectorX(i)=(vectorY(i)-suma1)/matrizR(i,i);
end

end