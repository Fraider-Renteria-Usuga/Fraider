import numpy as np
from math import exp
def llenarMyb(n):
    matriz=np.zeros((n,n))
    vectorSol=np.zeros(n)
    print("Introduce los coeficientes de la matriz ")
    for i in range(0,n):
      for j in range(0,n):
        matriz[i][j]=input("Elemento a["+str(i+1)+","+str(j+1)+"] = ")
      vectorSol[(i)]=input("b["+str(i+1)+"] = ")
    return(matriz,vectorSol)
def llenarMatriz_nxn(n):
    matriz=np.zeros((n,n))
    print("Introduce los coeficientes de la matriz ")
    for i in range(0,n):
      for j in range(0,n):
        matriz[i][j]=input("Elemento a["+str(i+1)+","+str(j+1)+"] = ")
    return(matriz)
def sustRegre(matriz,vectorSol):
    n=len(matriz)
    sln=np.zeros(n)
    if matriz[n-1][n-1]!=0:
        sln[n-1]=vectorSol[n-1]/matriz[n-1][n-1]
    for i in range(n-2,-1,-1):
        cont=0
        for j in range(n):
            cont =cont+matriz[i][j]*sln[j]
        if matriz[i][i]!=0:
            sln[i]=(vectorSol[i]-cont) / matriz[i][i]
    return (sln)
def sustProgre(matriz,vectorSol):
    n=len(matriz)
    sln=np.zeros(n)
    sln[0]=vectorSol[0]/matriz[0][0]
    for i in range(1,n):
        cont=0
        for j in range(i):
            cont+=matriz[i][j]*sln[j]
        sln[i]=((vectorSol[i]-cont)/(matriz[i][i]))
    return(sln)
def f(x):
    y=(3*x)+6
    #y=exp(x)-6*x
    return(y)