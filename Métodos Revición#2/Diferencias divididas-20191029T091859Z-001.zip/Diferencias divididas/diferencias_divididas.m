format rat

z=input("cuantos puntos desea ingresar: ");
x=zeros(0);
y=zeros(0);
a=zeros(z,z+1);

for i=1:z
    X=input("ingrese x: ");
    Y=input("ingrese y: ");
    x=[x;X];
    y=[y;Y];
end
v=length(x);
a=zeros(v,v+1);
a(:,1)=x;
a(:,2)=y;
[m,n]=size(a);

cont=0;
for i=2:m
    cont=cont+1;
    for j=i:m
        y=1;
        p=(a(j,i));
        p1=(a((j-1),i));
        u=a(j,(i-cont));
        u1=a((j-cont),(y));
        a(j,(i+1))=(p-p1)/(u-u1);
    end
end
disp(a)