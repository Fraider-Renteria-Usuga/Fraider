from funciones import f
import numpy as np
from sympy import *
def newtondif(xi,yi):
    n=len(xi)
    x=symbols('x')
    cont=0
    for k in range(n):
        cont+=1
        for i in range(cont,n):
            p=yi[i][cont-1]
            u = yi[i-1][cont-1]
            col = (p-u) / (xi[i]-xi[i-cont])
            yi[i].append(col)
    p=0
    print("xi   f[xi] ")
    for i in range(n):
        print(str(xi[i])+str(yi[i]))
        t=yi[i][i]
        for k in range(i):
            t*=(x - xi[k])
        p+=t
    print("El polinomio es: \n" + str(p))