from sympy import *
def lagrange(xi,yi):
    n=len(xi)
    x=symbols('x')
    L=[]
    for i in range(n):
        num=1
        den=1
        for j in range(n):
            if xi[i]!=xi[j]:
                num*=expand(x-xi[j])
                den*=(xi[i]-xi[j])
        L.append(expand(num)/den)
    pol=0
    for i in range(n):
        pol+=yi[i]*L[i]
    return(L,(expand(pol)))
#Comando para imprimir de una manera clara al usuario
#for i in range(len(L)):
    #print("L" + str(i) + ": " + str(L[i]))
#print("p(x): " + str(pol))